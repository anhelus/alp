import hashlib
import os
from time import sleep


'''
funzione che imposta una pausa nell'applicazione espressa in secondi
'''
def pausa(s):
    sleep(s)

'''
Funzione che rimuove il testo dalla console
'''
def ConsoleClear():
    os.system('cls')

'''
CLasse per generare MD5 hash
'''
class Hashmd5():
    def __init__(self, strPassw):
        self.strPassw = strPassw

    def hashPassword(self):
        hashPassw = hashlib.md5(self.strPassw.encode())
        return hashPassw.hexdigest()

'''
Classe che definisce colori testo per console
'''
class ColorText:
    ROSSO = '\033[0;31m'
    ROSSO_CHIARO = "\033[1;31m"
    BLU = '\033[94m'
    CYAN = '\033[96m'
    VERDE = '\033[92m'
    VERDE_CHIARO = "\033[1;32m"
    ARANCIONE = '\033[93m'
    NOCOLOR = '\033[0m'
