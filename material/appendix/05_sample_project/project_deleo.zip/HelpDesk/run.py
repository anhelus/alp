#riferimento al package frontend
from frontend.client import Client as Frontend
#riferimento al package backend
from backend.client import Client as Backend
from lib import ConsoleClear

#punto di ingresso nell'applicazione
def mainApp():
    azione = ''
    ConsoleClear()
    while (azione not in (1,2,3)):
        azione = input("Accesso: [Utente - 1, Admin - 2, Esci - 3] ").strip()
        if (azione == '1'):
            ConsoleClear()
            cl = Frontend()
            #se login fallisce torna al chiamante
            cl.login()
        elif (azione == '2'):
            ConsoleClear()
            cl = Backend()
            #se login fallisce torna al chiamante
            cl.login()
        elif (azione == '3'):
            quit()

#quando uno script è eseguito direttamente, python assegna alla variabile speciale __name__
#il valore __main__
if __name__ == "__main__":
   mainApp()
