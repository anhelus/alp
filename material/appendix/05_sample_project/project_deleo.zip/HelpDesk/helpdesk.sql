-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 15, 2022 alle 21:18
-- Versione del server: 5.7.17
-- Versione PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `helpdesk`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `interventi`
--

CREATE TABLE `interventi` (
  `id` int(11) NOT NULL,
  `descrizione` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `so` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hdsw` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `priorita` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stato` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'in attesa',
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fk_utente` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `interventi`
--

INSERT INTO `interventi` (`id`, `descrizione`, `so`, `device`, `hdsw`, `priorita`, `stato`, `data`, `fk_utente`) VALUES
(3, 'Alimentatore Rotto, prego intervenire quanto prima', 'windows', 'pc', 'hardware', 'alta', 'risolto', '2022-05-02 12:28:27', 2),
(20, 'scheda audio non rilevata', 'linux', 'pc', 'hardware', 'alta', 'in attesa', '2022-05-15 19:45:15', 2),
(18, 'installazione software autocad', 'windows', 'pc', 'software', 'urgente', 'in attesa', '2022-05-15 18:07:05', 2),
(19, 'Update del sistema operativo e configurazione stampante di rete', 'windows', 'pc', 'software', 'alta', 'in lavorazione', '2022-05-15 19:43:05', 2),
(16, 'i documenti inviati non vengono stampanti correttamente.', 'windows', 'stampante', 'software', 'urgente', 'in attesa', '2022-05-15 11:49:00', 2),
(15, 'Update del sistema operativo e configurazione stampante di rete', 'android', 'tablet', 'software', 'alta', 'in attesa', '2022-05-15 11:41:37', 3),
(12, 'rimozione virus informatico dal pc, arrivato tramite allegato posta', 'windows', 'pc', 'software', 'urgente', 'in attesa', '2022-05-03 01:23:20', 2),
(21, 'aggiornmento sistema operativo e backup dati', 'android', 'tablet', 'software', 'urgente', 'in attesa', '2022-05-15 21:16:11', 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cognome` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cell` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `settore` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `piano` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stanza` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'False'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `nome`, `cognome`, `email`, `password`, `cell`, `settore`, `piano`, `stanza`, `admin`) VALUES
(1, 'Antonio', 'de Leo', 'assistenza@azienda.it', '81dc9bdb52d04dc20036dbd8313ed055', '327-5994406', 'Comunicazione', '2°', '11', 'True'),
(2, 'Alessia', 'Rossi', 'arossi@azienda.it', '81dc9bdb52d04dc20036dbd8313ed055', '333-525652', 'Risorse Umane', '5°', '25', 'False'),
(3, 'Alberto', 'Bianchi', 'abianchi@azienda.it', '81dc9bdb52d04dc20036dbd8313ed055', '333-2569856', 'Finanziario', '3°', '7', 'False');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `interventi`
--
ALTER TABLE `interventi`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `nome` (`nome`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `interventi`
--
ALTER TABLE `interventi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
