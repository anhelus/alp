import mysql.connector
from mysql.connector import Error
'''
Costanti connessione database MySql
'''
class DbConst():
    HOST = 'localhost'
    USER = 'root'
    PW = ''
    DB = 'helpdesk'

'''
Classe per accesso al DB
'''
class DbmsMysql():
    server_info = ''
    conn = ''
    cursore = ''

    '''
    Apre connessione Db
    '''

    def dbConnOpen(self):
        try:
            self.conn = mysql.connector.Connect(host=DbConst.HOST,
                                                user=DbConst.USER,
                                                password=DbConst.PW,
                                                database=DbConst.DB)
            if self.conn.is_connected():
                DbmsMysql.server_info = self.conn.get_server_info()
                self.cursore = self.conn.cursor()
                return self.cursore
        except Error as e:
            print("Errore connessione Mysql", e)

    '''
    Chiude connessione Db
    '''

    def dbConnClose(self):
        if self.conn.is_connected():
            self.cursore.close()
            self.conn.close()

    '''
    Insert dati
    '''

    def insert(self, strSql, dati):
        try:
            cursore = self.dbConnOpen()
            cursore.execute(strSql, dati)
            self.conn.commit()
        except Error as e:
            print("Errore Inserimento dati", e)
        finally:
            self.dbConnClose()

    def update(self, strSql, dati):
        try:
            cursore = self.dbConnOpen()
            cursore.execute(strSql, dati)
            self.conn.commit()
        except Error as e:
            print("Errore Aggiornamento dati", e)
        finally:
            self.dbConnClose()

    '''
    Recupero di un solo record
    '''
    def fetchOne(self, strSql):
        try:
            cursore = self.dbConnOpen()
            cursore.execute(strSql)
            rec = cursore.fetchone()
            if (rec == None):
                return False
            else:
                return rec
        except Error as e:
            print("Errore recupero record", e)
        finally:
            self.dbConnClose()

    '''         
    Recupero di più record
    '''
    def fetchAll(self, strSql):
        try:
            cursore = self.dbConnOpen()
            cursore.execute(strSql)
            return cursore.fetchall()
        except Error as e:
            print("Errore recupero dati", e)
        finally:
            self.dbConnClose()

    '''
    Delete record
    '''
    def delete(self, strSql):
        try:
            cursore = self.dbConnOpen()
            cursore.execute(strSql)
            self.conn.commit()
        except Error as e:
            print("Errore eliminazione dati", e)
        finally:
            self.dbConnClose()

