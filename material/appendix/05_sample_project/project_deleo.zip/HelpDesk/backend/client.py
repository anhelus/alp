import textwrap
from datetime import datetime
from dbLib import DbmsMysql
from lib import Hashmd5, ColorText,ConsoleClear,pausa
import pwinput


'''
Classe backend, utilizzata dai tecnici informatici per evadere le richieste di assistenza tecnica
'''

class Client():
    user = ''
    password = ''
    iduser = ''
    loginStatus = False;
    dbMy = ''
    lista_interventi = []

    def __init__(self):
        self.dbMy = DbmsMysql()

    def login(self):
        ConsoleClear()
        print(f"{ColorText.ARANCIONE}********* HelpDesk Backend Login *********{ColorText.NOCOLOR}")
        pausa(3)
        ConsoleClear()
        if (self.loginStatus == False):
            while (True):
                self.user = input("User: ").strip()
                if (self.user == ''):
                    ConsoleClear()
                else:
                    ConsoleClear()
                    break

            while (True):
                self.password = pwinput.pwinput('Password: ', mask='*').strip()
                if (self.password == ''):
                    ConsoleClear()
                else:
                    ConsoleClear()
                    break

            hmd5 = Hashmd5(self.password).hashPassword()
            strSql = f"SELECT * FROM utenti WHERE email ='{self.user}' AND password ='{hmd5}' AND admin='True'"
            res = self.dbMy.fetchOne(strSql)
            if (res == False):
                print(f"{ColorText.ROSSO}User o password errati.{ColorText.NOCOLOR}")
                print(f"{ColorText.ARANCIONE}**********************************{ColorText.NOCOLOR}")
            else:
                self.iduser = res[0]
                self.loginStatus = True
                print(f"{ColorText.ARANCIONE}**********************************{ColorText.NOCOLOR}")
                print(f"{ColorText.VERDE_CHIARO}Connesso MySql versione {DbmsMysql.server_info}{ColorText.NOCOLOR}")
                print(f"{ColorText.VERDE_CHIARO}{datetime.today().strftime('%Y-%m-%d %H:%M')}")
                print(f"{ColorText.ARANCIONE}**********************************{ColorText.NOCOLOR}")
                pausa(3)
                self.startApp()

    def activity(self, strAzione):
        descrizioneProb = ''
        device = ''
        so = ''
        hdsw = ''
        priorita = ''

        if (strAzione == 'sr'):
            stato_richiesta = ''
            while (True):
                id_richiesta = input("Inserisci id richiesta: ").strip()
                if(id_richiesta.isdigit()):
                    if (int(id_richiesta) not in self.lista_interventi):
                        print("id richiesta non valido")
                        pausa(3)
                        ConsoleClear()
                    else:
                        ConsoleClear()
                        break
                else:
                    print("id richiesta non valido")
                    pausa(3)
                    ConsoleClear()

            while (True):
                stato_richiesta = input("Modifica stato richiesta: [in lavorazione - 1, risolto - 2, menù principale - m]").strip()

                if (stato_richiesta in ('m', 'M')):
                    ConsoleClear()
                    self.startApp()

                if (stato_richiesta not in ('1', '2')):
                    print("stato non valido")
                    pausa(3)
                    ConsoleClear()
                else:
                    if (stato_richiesta == '1'):
                        stato_richiesta = "in lavorazione"
                    else:
                        stato_richiesta = "risolto"
                    ConsoleClear()
                    break

            strSqlList = f"UPDATE interventi SET stato =%s WHERE id=%s"
            dati = (stato_richiesta, id_richiesta)
            self.dbMy.update(strSqlList, dati)
            ConsoleClear()
            print(f"{ColorText.ARANCIONE}Stato aggiornato.{ColorText.NOCOLOR}")
            pausa(4)
            self.startApp()
        elif (strAzione == 'er'):
            strSqlList = """SELECT interventi.data,utenti.nome,utenti.cognome,
                            utenti.id,interventi.priorita,interventi.stato,interventi.descrizione,
                            interventi.so,interventi.device,interventi.hdsw,utenti.stanza,utenti.piano,
                            utenti.settore, interventi.id FROM interventi,utenti WHERE utenti.id = interventi.fk_utente 
                            ORDER BY data DESC"""
            elenco = self.dbMy.fetchAll(strSqlList)
            ConsoleClear()
            print(
                f"{ColorText.VERDE_CHIARO}********** Elenco richieste di assistenza ricevute **********{ColorText.NOCOLOR}")
            for i in elenco:
                stato = i[5]
                if (stato == 'in attesa'):
                    stato = f"{ColorText.ROSSO}{stato}{ColorText.NOCOLOR}"
                elif (stato == 'in lavorazione'):
                    stato = f"{ColorText.BLU}{stato}{ColorText.NOCOLOR}"
                elif (stato == 'risolto'):
                    stato = f"{ColorText.VERDE}{stato}{ColorText.NOCOLOR}"

                print(f"{ColorText.ARANCIONE}Data:{ColorText.NOCOLOR} {i[0]}")
                print(
                    f"{ColorText.ARANCIONE}Nome:{ColorText.NOCOLOR} {i[1]} - {ColorText.ARANCIONE}Cognome:{ColorText.NOCOLOR} {i[2]} - {ColorText.ARANCIONE}id richiesta:{ColorText.NOCOLOR} {i[13]}")
                print(
                    f"{ColorText.ARANCIONE}Settore:{ColorText.NOCOLOR} {i[12]} - {ColorText.ARANCIONE}piano:{ColorText.NOCOLOR} {i[11]} - {ColorText.ARANCIONE}stanza:{ColorText.NOCOLOR} {i[10]}")
                print(
                    f"{ColorText.ARANCIONE}Priorità:{ColorText.NOCOLOR} {i[4]} - {ColorText.ARANCIONE}Stato:{ColorText.NOCOLOR} {stato}")
                print(
                    f"{ColorText.ARANCIONE}So:{ColorText.NOCOLOR} {i[7]} - {ColorText.ARANCIONE}Device:{ColorText.NOCOLOR}  {i[8]} - {ColorText.ARANCIONE}Tipo:{ColorText.NOCOLOR} {i[9]}")
                print(f"{ColorText.ARANCIONE}Descrizione:{ColorText.NOCOLOR} \n{textwrap.fill(i[6], 40)}")
                print(
                    f"{ColorText.VERDE_CHIARO}********************************************************{ColorText.NOCOLOR}")

            print("Elenco terminato")
            input("Premi un tasto per tornare al menù principale...")
            ConsoleClear()
            self.startApp()
        elif (strAzione == 'delr'):
            ConsoleClear()
            while (True):
                id_richiesta = input("Inserisci id richiesta da eliminare: [menù principale - m] ").strip()
                if(id_richiesta in ('m','M')):
                    ConsoleClear()
                    self.startApp()
                try:
                    id_richiesta = int(id_richiesta)
                except ValueError:
                    print("id richiesta deve essere un valore numerico intero")
                    pausa(3)
                    ConsoleClear()
                    continue
                if (id_richiesta not in self.lista_interventi):
                    print("id richiesta non presente nel db")
                    pausa(3)
                    ConsoleClear()
                else:
                    ConsoleClear()
                    break


            strSqlDel = f"DELETE FROM interventi WHERE id = {id_richiesta}"
            # dati = (id_richiesta)
            self.dbMy.delete(strSqlDel)
            ConsoleClear()
            print(f"{ColorText.ARANCIONE}Richiesta eliminata.{ColorText.NOCOLOR}")
            pausa(4)
            self.startApp()

    def startApp(self):
        if (self.loginStatus == True):
            strSqlListId = "SELECT interventi.id FROM interventi"
            elenco = self.dbMy.fetchAll(strSqlListId)
            for i in elenco:
                self.lista_interventi.append(i[0])

            ConsoleClear()
            azione = ''
            while (azione not in ['1', '2', '3','4']):
                azione = input(
                    f"{ColorText.ARANCIONE}Scegli:{ColorText.NOCOLOR} [Elenco richieste - 1, Modifica stato richiesta - 2, Elimina richiesta - 3, Esci - 4] ").strip()
            if (azione == '1'):
                self.activity('er')
            elif (azione == '2'):
                self.activity('sr')
            elif (azione == '3'):
                self.activity('delr')
            else:
                ConsoleClear()
                quit()