import textwrap
from datetime import datetime
from dbLib import DbmsMysql
from lib import Hashmd5, ColorText,ConsoleClear,pausa
import pwinput


'''
Classe client, utilizzata dagli utenti per le richieste di assistenza tecnica
'''
class Client():
    user = ''
    password = ''
    iduser = ''
    loginStatus = False;
    dbMy = ''

    def __init__(self):
        self.dbMy = DbmsMysql()

    def login(self):
        ConsoleClear()
        print(f"{ColorText.ARANCIONE}********* HelpDesk User Login *********{ColorText.NOCOLOR}")
        pausa(3)
        ConsoleClear()
        if (self.loginStatus == False):
            while (True):
                self.user = input("User: ").strip()
                if(self.user == ''):
                    ConsoleClear()
                else:
                    ConsoleClear()
                    break

            while (True):
                self.password = pwinput.pwinput('Password: ',mask='*').strip()
                if(self.password == ''):
                    ConsoleClear()
                else:
                    ConsoleClear()
                    break

            hmd5 = Hashmd5(self.password).hashPassword()
            strSql = f"SELECT * FROM utenti WHERE email ='{self.user}' AND password ='{hmd5}'"
            res = self.dbMy.fetchOne(strSql)
            if (res == False):
                print(f"{ColorText.ROSSO}User o password errati.{ColorText.NOCOLOR}")
                print(f"{ColorText.ARANCIONE}**********************************{ColorText.NOCOLOR}")
            else:
                self.iduser = res[0]
                self.loginStatus = True
                print(f"{ColorText.ARANCIONE}**********************************{ColorText.NOCOLOR}")
                print(f"{ColorText.VERDE_CHIARO}Connesso MySql versione {DbmsMysql.server_info}{ColorText.NOCOLOR}")
                print(f"{ColorText.VERDE_CHIARO}{datetime.today().strftime('%Y-%m-%d %H:%M')}")
                print(f"{ColorText.ARANCIONE}**********************************{ColorText.NOCOLOR}")
                pausa(3)
                self.startApp()

    def activity(self, strAzione):

        descrizioneProb = ''
        device = ''
        so = ''
        hdsw = ''
        priorita = ''

        if (strAzione == "ra"):
            print(f"{ColorText.ARANCIONE}Compila il form di richiesta assistenza tecnica{ColorText.NOCOLOR}")
            print(f"{ColorText.ROSSO}Indicare un valore tra quelli indicati{ColorText.NOCOLOR}")
            print()
            pausa(4)
            ConsoleClear()
            while (True):
                device = input(f"{ColorText.ARANCIONE}Device:{ColorText.NOCOLOR} [pc,netbook,tablet,smartphone,stampante] ").lower().strip()
                if (device not in ('pc', 'notebook', 'tablet', 'smartphone','stampante')):
                    ConsoleClear()
                else:
                    ConsoleClear()
                    break

            while (True):
                hdsw = input(f"{ColorText.ARANCIONE}Ambito:{ColorText.NOCOLOR} [hardware, software] ").lower().strip()
                if (hdsw not in ('hardware', 'software')):
                    ConsoleClear()
                else:
                    ConsoleClear()
                    break

            while (True):
                so = input(f"{ColorText.ARANCIONE}Sistema operativo:{ColorText.NOCOLOR} [windows, macos, linux, android] ").lower().strip()
                if (so not in ('windows', 'macos', 'linux', 'android')):
                    ConsoleClear()
                else:
                    ConsoleClear()
                    break

            while (True):
                descrizioneProb = input(f"{ColorText.ARANCIONE}Descrizione problema (min 20 caratteri): {ColorText.NOCOLOR}")
                if (descrizioneProb == '' or len(descrizioneProb) < 20):
                    ConsoleClear()
                else:
                    ConsoleClear()
                    break

            while (True):
                priorita = input(f"{ColorText.ARANCIONE}Priorità:{ColorText.NOCOLOR}  [urgente, alta, medio, bassa] ").lower().strip()
                if (priorita not in ('urgente', 'alta', 'medio', 'bassa')):
                    ConsoleClear()
                else:
                    ConsoleClear()
                    break

            ##salviamo i dati nel database
            strSqlInsert = "INSERT INTO interventi (descrizione,so,device,hdsw,priorita,stato,fk_utente) VALUES (%s, %s,%s, %s,%s, %s,%s) "
            dati = (descrizioneProb, so, device, hdsw, priorita, "in attesa", self.iduser)
            self.dbMy.insert(strSqlInsert, dati)
            print(f"{ColorText.ARANCIONE}La tua richiesta è stata trasmessa, sarai ricontattato da un tecnico.{ColorText.NOCOLOR}")
            pausa(4)
            self.startApp()
        elif (strAzione == 'er'):
            strSqlList = f"SELECT utenti.id,descrizione,so,device,hdsw,priorita,stato,data FROM interventi,utenti WHERE utenti.id = interventi.fk_utente and utenti.id = {self.iduser}"
            elenco = self.dbMy.fetchAll(strSqlList)
            ConsoleClear()
            print(f"{ColorText.VERDE_CHIARO}********** Elenco richieste di assistenza inviate **********{ColorText.NOCOLOR}")
            for i in elenco:
                stato = i[6]
                if(stato == 'in attesa'):
                    stato =f"{ColorText.ROSSO}{stato}{ColorText.NOCOLOR}"
                elif(stato == 'in lavorazione'):
                    stato = f"{ColorText.BLU}{stato}{ColorText.NOCOLOR}"
                elif(stato == 'risolto'):
                    stato = f"{ColorText.VERDE}{stato}{ColorText.NOCOLOR}"

                print(f"{ColorText.ARANCIONE}Data:{ColorText.NOCOLOR}  {i[7]}")
                print(f"{ColorText.ARANCIONE}Priorità:{ColorText.NOCOLOR} {i[5]} - {ColorText.ARANCIONE}Stato:{ColorText.NOCOLOR} {stato}")
                print(f"{ColorText.ARANCIONE}Descrizione:{ColorText.NOCOLOR}\n{textwrap.fill(i[1], 40)}")
                print(f"{ColorText.ARANCIONE}So:{ColorText.NOCOLOR} {i[2]} - {ColorText.ARANCIONE}Device:{ColorText.NOCOLOR} {i[3]} - {ColorText.ARANCIONE}Tipo: {i[4]}")
                print(f"{ColorText.VERDE_CHIARO}************************************************************{ColorText.NOCOLOR}")
            print("Elenco terminato")
            input("Premi un tasto per tornare al menù principale...")
            ConsoleClear()
            self.startApp()

    def startApp(self):
        if (self.loginStatus == True):
            ConsoleClear()
            azione = ''
            while (azione not in ['1', '2', '3']):
                azione = input(f"{ColorText.ARANCIONE}Scegli:{ColorText.NOCOLOR} [Richiesta assistenza - 1, Elenco richieste - 2, Esci - 3] ").strip()
            if (azione == '1'):
                self.activity('ra')
            elif (azione == '2'):
                self.activity('er')
            else:
                quit()


